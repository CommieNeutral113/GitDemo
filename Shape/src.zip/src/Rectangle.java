public class Rectangle extends Shape {
    protected double width;
    protected double length;

    public Rectangle(){}

    /** abc. */
    public Rectangle(double width, double length) {
        this.width = width;
        this.length = length;
    }

    /** abc. */
    public Rectangle(double width, double length, String color, boolean filled) {
        super(color, filled);
        this.width = width;
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    /** abc. */
    @Override
    public double getArea() {
        return length * width;
    }

    /** abc. */
    @Override
    public double getPerimeter() {
        return 2 * (length + width);
    }

    /** abc. */
    @Override
    public String toString() {
        String output = ("Rectangle[width=" + width);
        output += (",length=" + length);
        output += (",color=" + color);
        output += (",filled=" + filled + "]");
        return output;
    }
}
